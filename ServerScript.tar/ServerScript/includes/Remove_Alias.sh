#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################

echo "            "
echo "You are now going to remove Alias"
read -p "Please Enter Main Domain: " domain
read -p "Please Enter Alias: " alias

if grep $alias $domain; then
    sed -i 's/$alias/d' /etc/httpd/conf.d/$domain.conf
    else
    echo "Alias not exist"
fi

echo "Loading...................................................."
echo -ne '##################                                (33%)\r'
sleep 1
echo -ne '###################################               (70%)\r'
sleep 1
echo -ne '################################################ (100%)\r'
echo -ne '\n'
echo "The Alias : $alias have been removed from Domain : $domain"

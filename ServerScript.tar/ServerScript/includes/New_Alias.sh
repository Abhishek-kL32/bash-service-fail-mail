#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################

echo "            "
echo "You are now going to add new Alias, please make suer you point"
echo "the Alias to main server ip to be able activating SSL"
read -p "Please Enter Main Domain: " domain
read -p "Please Enter Alias: " alias

if grep $alias $domain; then
    echo "Alias already exist"
    else
    sed -i 's/ServerAlias  $domain/ServerAlias  $domain $alias/' /etc/httpd/conf.d/$domain.conf
fi

echo "Loading...................................................."
echo -ne '##################                                (33%)\r'
sleep 1
echo -ne '###################################               (70%)\r'
sleep 1
echo -ne '################################################ (100%)\r'
echo -ne '\n'
echo "The New Alias : $alias have been add to Domain : $domain"
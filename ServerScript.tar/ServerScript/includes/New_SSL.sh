#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################

echo "            "
echo "            "
echo "            "
echo "            "
echo "            Welcome to Server Control Installation Script"
echo "            "
echo "            "
echo "This script will used for manageing hosting server, it will help installing"
echo "APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server"
echo "Also it used for adding new domains, alias's, subdomains and remove them"
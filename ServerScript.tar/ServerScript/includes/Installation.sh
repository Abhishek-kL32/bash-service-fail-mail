#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################


echo "            "
echo "This script will used for installing the server and DNS"
echo "            "
echo "            "
read -p "Please Enter First IPv4: " publicip
read -p "Please Enter Second IPv4: " publicipnd
read -p "please Enter FQDN Domain: " domain
echo "Pleas Wait"
echo "Loading..................."
echo "Loading......................"
echo "Loading.............................."
echo "Loading........................................"
echo "Loading...................................................."

# Updating Kernal
dnf --disablerepo '*' --enablerepo=extras swap centos-linux-repos centos-stream-repos --allowerasing -y
dnf distro-sync -y
yum update -y
yum install epel-release -y
yum install -y gcc gcc-c++ wget git nano rsync

# Disable selinux
if [ -s /etc/selinux/config ] && grep 'SELINUX=enforcing' /etc/selinux/config; then
    sed -i 's/SELINUX=enforcing/SELINUX=disabled/g' /etc/selinux/config
    setenforce 0
fi

echo "            "
echo "            "
echo "Starting Installing Apache Pleas Wait"
sleep 2
echo "Loading..................."
echo "Loading......................"
echo "Loading.............................."
echo "Loading........................................"
echo "Loading...................................................."
echo -ne '##################                                (33%)\r'
sleep 1
echo -ne '###################################               (70%)\r'
sleep 1
echo -ne '################################################ (100%)\r'
echo -ne '\n'

hostnamectl set-hostname server.$domain
echo "$publicip server.$domain" >> /etc/hosts
yum install httpd -y
sudo systemctl start httpd
sudo systemctl enable httpd
mkdir -p /var/www/$domain
chown -R apache:apache /var/www/$domain
cd /var/www/$domain
touch /etc/httpd/conf.d/$domain.conf
#Define website dir
webdir="/var/www/$domain"
DocumentRoot="$webdir/public_html"
logsdir="$webdir/logs"
mkdir -p $DocumentRoot $logsdir
chown -R apache:apache $webdir
#Create vhost configuration file
cat >/etc/httpd/conf.d/$domain.conf<<EOF
<virtualhost *:80>
ServerName  $domain
ServerAlias  $domain
DocumentRoot  $DocumentRoot
CustomLog $logsdir/access.log combined
DirectoryIndex index.php index.html
<Directory $DocumentRoot>
Options +Includes -Indexes
AllowOverride All
Order Deny,Allow
Allow from All
</Directory>
</virtualhost>
EOF
echo "################################"
echo "#       APACHE INSTALLED       #"
echo "################################"
sleep 2
echo "            "
echo "            "
echo "Starting Installing MariaDB"
echo "Loading..................."
echo "Loading......................"
echo "Loading.............................."
echo "Loading........................................"
echo "Loading...................................................."
echo -ne '##################                                (33%)\r'
sleep 1
echo -ne '###################################               (70%)\r'
sleep 1
echo -ne '################################################ (100%)\r'
echo -ne '\n'
echo ""
echo "            "
echo "You are useing Centos 8"
echo "please wait while installing EPEL and REMI repositories"
yum -y install mariadb mariadb-server
service mariadb start
systemctl enable mariadb
/usr/bin/mysqladmin password VxP8U3V6M9zWv3s
/usr/bin/mysql -uroot -pVxP8U3V6M9zWv3s <<EOF
drop database if exists test;
delete from mysql.user where user='';
update mysql.user set password=password('VxP8U3V6M9zWv3s') where user='root';
delete from mysql.user where not (user='root') ;
flush privileges;
exit
EOF
echo "################################"
echo "#       MySQL  INSTALLED       #"
echo "################################"
sleep 2
echo "            "
echo "            "
echo "Starting Installing Python Pleas Wait"
echo "Loading..................."
echo "Loading......................"
echo "Loading.............................."
echo "Loading........................................"
echo "Loading...................................................."
echo "please wait while installing EPEL and REMI repositories"
sleep 2
yum -y install python3 python3-paramiko
dnf install -y https://extras.getpagespeed.com/release-latest.rpm
sudo yum -y install python3 python3-devel python3-pip mod_proxy_uwsgi gcc


echo "###########################################"
echo "#       Python & Flask -- INSTALLED       #"
echo "###########################################"
sleep 2

echo "            "
echo "            "
echo "Starting Installing LetsEncrypt SSL"
echo "Loading..................."
echo "Loading......................"
echo "Loading.............................."
yum -y install yum-utils
yum install certbot certbot-apache mod_ssl -y
certbot run -n --apache --agree-tos -d $domain  -m  support@oxcesseg.com  --redirect
sudo systemctl restart httpd

echo "################################"
echo "#    LetsEncrypt INSTALLED     #"
echo "################################"
sleep 2

echo "            "
echo "            "
echo "Starting Installing Bind and Adjust Nameservers"
echo "Loading..................."
echo "Loading......................"
echo "Loading.............................."
yum -y install bind bind-utils
ptr=$(echo $publicip | awk -F. -vOFS=. '{print $3,$2,$1,"in-addr.arpa"}')
ptrlast=$(echo $publicip | awk -F. -vOFS=. '{print $4}')
SERIAL=$(date +%Y%m%d01)
echo "zone \"$domain\" IN { " >>  /etc/named.conf
echo "    type master;"  >>  /etc/named.conf
echo "    file \"$domain.db\";" >>  /etc/named.conf
echo "};"  >>  /etc/named.conf
echo ""
echo "zone \"$ptr\" IN { " >>  /etc/named.conf
echo "    type master;"  >>  /etc/named.conf
echo "    file \"$domain-ptr.db\";" >>  /etc/named.conf
echo "};"  >>  /etc/named.conf
echo ""
touch /var/named/$domain.db
echo "; Zone file for $domain"
echo "\$TTL 14400" >> /var/named/$domain.db
echo "@    86400        IN      SOA     ns1.$domain. postmaster.$domain. (" >> /var/named/$domain.db
echo "                                $SERIAL  ; Serial" >> /var/named/$domain.db
echo "                                    604800 ; refresh" >> /var/named/$domain.db
echo "                                     86400 ; retry" >> /var/named/$domain.db
echo "                                   2419200 ; expiration" >> /var/named/$domain.db
echo "                                    604800 ; TTL negative cache" >> /var/named/$domain.db
echo "  ); " >> /var/named/$domain.db
echo "@       86400   IN      NS              ns1.$domain." >> /var/named/$domain.db
#echo "@       86400   IN      NS              ns2.$domain." >> /var/named/$domain.db
echo "@       IN      MX      10       mail.$domain." >> /var/named/$domain.db
echo "@ IN A        $publicip " >> /var/named/$domain.db
echo "ns1 14400 IN A $publicip " >> /var/named/$domain.db
#echo "ns2 14400 IN A $publicipnd " >> /var/named/$domain.db
echo "www 14400 IN A $publicip " >> /var/named/$domain.db
echo "ns1.$domain" > /var/named/autons1
#echo "ns2.$domain" > /var/named/autons2
touch /var/named/$domain-ptr.db
echo "\$TTL 3H" >> /var/named/$domain-ptr.db
echo "@       IN      SOA     ns1.$domain.        postmaster.$domain. (" >> /var/named/$domain-ptr.db
echo "                       $SERIAL  ; Serial" >> /var/named/$domain-ptr.db
echo "                    604800 ; refresh" >> /var/named/$domain-ptr.db
echo "                     86400 ; retry" >> /var/named/$domain-ptr.db
echo "                   2419200 ; expiration" >> /var/named/$domain-ptr.db
echo "                    604800 ; TTL negative cache" >> /var/named/$domain-ptr.db
echo "  ); " >> /var/named/$domain-ptr.db
echo " " >> /var/named/$domain-ptr.db
echo "        NS      ns1.$domain." >> /var/named/$domain-ptr.db
#echo "        NS      ns2.$domain." >> /var/named/$domain-ptr.db
echo " " >> /var/named/$domain-ptr.db
echo "$ptrlast IN PTR $domain." >> /var/named/$domain-ptr.db
sed -i "s/127.0.0.1/any/g" /etc/named.conf
sed -i "s/listen-on-v6/#listen-on-v6/g"  /etc/named.conf
sed -i "s/localhost;/any;/g" /etc/named.conf 
systemctl enable named
chown -R named:named /var/named/*.db
service named start

echo "#####################"
echo "#   Bind INSTALLED  #"
echo "#####################"


systemctl restart httpd
systemctl restart mariadb
systemctl restart named

echo "
Account Details
====================================
IP Address: $publicip
Domain: $domain
webdir="/var/www/$domain"
DocumentRoot="$webdir/public_html"
logsdir="$webdir/logs"
====================================
mysql root password VxP8U3V6M9zWv3s
====================================
NameServers:                     
ns1.$domain > $publicip          
ns1.$domain > $publicipnd        
====================================
"

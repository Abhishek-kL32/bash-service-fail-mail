ServerScrip/
includes/ run.sh

Installation.sh   is only facing ssl adding issue 
New_Domain.sh   is working fine
Remove_Domain.sh  is working fine
New_SSL.sh  no script found
New_Alias.sh not working
Remove_Alias.sh not working   

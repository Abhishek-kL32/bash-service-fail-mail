#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################

NS1=`cat /var/named/autons1`
NS2=`cat /var/named/autons2`

echo "            "
echo "You are now going to add new Domain, please make suer you point"
echo "the domain or subdomain to main server ip to be able activating SSL"
read -p "please Enter FQDN Domain: " domain

mkdir -p /var/www/$domain
chown -R apache:apache /var/www/$domain
cd /var/www/$domain
touch /etc/httpd/conf.d/$domain.conf
#Define website dir
webdir="/var/www/$domain"
DocumentRoot="$webdir/public_html"
logsdir="$webdir/logs"
mkdir -p $DocumentRoot $logsdir
chown -R apache:apache $webdir
#Create vhost configuration file
cat >/etc/httpd/conf.d/$domain.conf<<EOF
<virtualhost *:80>
ServerName  $domain
ServerAlias  $domain
DocumentRoot  $DocumentRoot
CustomLog $logsdir/access.log combined
DirectoryIndex index.php index.html
<Directory $DocumentRoot>
Options +Includes -Indexes
AllowOverride All
Order Deny,Allow
Allow from All
</Directory>
</virtualhost>
EOF

certbot run -n --apache --agree-tos -d $domain  -m  support@oxcesseg.com  --redirect

echo "\$TTL 14400" >> /var/named/$domain.db
echo "@    86400        IN      SOA     $NS1. postmaster.$domain. (" >> /var/named/$domain.db
echo "                                $SERIAL  ; Serial" >> /var/named/$domain.db
echo "                                    604800 ; refresh" >> /var/named/$domain.db
echo "                                     86400 ; retry" >> /var/named/$domain.db
echo "                                   2419200 ; expiration" >> /var/named/$domain.db
echo "                                    604800 ; TTL negative cache" >> /var/named/$domain.db
echo "  ); " >> /var/named/$domain.db
echo "@       86400   IN      NS              $NS1." >> /var/named/$domain.db
echo "@       86400   IN      NS              $NS2." >> /var/named/$domain.db
echo "@       IN      MX      10       mail.$domain." >> /var/named/$domain.db
echo "@ IN A        $publicip " >> /var/named/$domain.db
echo "www 14400 IN A $publicip " >> /var/named/$domain.db

systemctl restart httpd
systemctl restart named

echo "Loading...................................................."
echo -ne '##################                                (33%)\r'
sleep 1
echo -ne '###################################               (70%)\r'
sleep 1
echo -ne '################################################ (100%)\r'
echo -ne '\n'

echo "
Account Details
====================================
IP Address: $publicip
Domain: $domain
webdir="/var/www/$domain"
DocumentRoot="$webdir/public_html"
logsdir="$webdir/logs"
====================================
NameServers:                
$NS1   
$NS2 
====================================
"
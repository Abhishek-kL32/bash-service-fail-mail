#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################

echo "            "
echo "Warning!! You are now going to remove Domain or subdomain"
echo -n "Pleas enter ( y ) to Continue or ( n ) leave screen : "
read choise1
if [ $choise1 = "y" ]; then
    read -p "Please Enter FQDN Domain: " domain
    echo "Warning!! please make sure you understanding this option will delete"
    echo "the domain and all entire related files and folders and virtualhost"
    echo -n "Are you sure from removing the domain [ y/n ] : "
    read choise2
    if [ $choise2 = "y" ]; then
        rm -rf /var/www/$domain
        rm -rf /etc/httpd/conf.d/$domain.conf
        rm -rf /var/named/$domain.db
        systemctl restart httpd
        systemctl restart named

        echo "Loading...................................................."
        echo -ne '##################                                (33%)\r'
        sleep 1
        echo -ne '###################################               (70%)\r'
        sleep 1
        echo -ne '################################################ (100%)\r'
        echo -ne '\n'
        echo "The Domain $domain have been removed"
        else 
        echo "Thanks for using our scripts goodbye"
	    exit
	fi
    else 
    echo "Thanks for using our scripts goodbye"
	exit
fi      

#!/bin/bash
################################################################################
#                            Server Control Scripts                            #
#                                                                              #
# This script will used for manageing hosting server, it will help installing  #
# APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server    #
#                                                                              #
# Created By : Eng. Mohamed Kamal                                              #
# Phone : +201062008120                                                        #
# Email : Mr.peacock2@gmail.com                                                #
# 10/Mar/2022 :  Original code created be the developer                        #
#                                                                              #
################################################################################

echo "            "
echo "            "
echo "            "
echo "            "
echo "            Welcome to Server Control Installation Script"
echo "            "
echo "            "
echo "This script will used for manageing hosting server, it will help installing"
echo "APACHE, SSL, MariaDB, Python, Flask, and help with configuring DNS server"
echo "Also it used for adding new domains, alias's, subdomains and remove them"


# Menu For Choise the requierd action
echo "	 Please choise your option"
echo " "
echo " "
echo "	 [1]-New Server Installation"
echo " 	 [2]-Add New Domain or Subdomain"
echo "	 [3]-Remove Domain or Subdomain"
echo "	 [4]-Add New Alias"
echo "	 [5]-Remove Alias"
echo -n "Enter your Choise : [ 1 or 2, etc..] : "
read choise2

if [ $choise2 = "1" ]; then
    echo "            "
    echo "            "
    echo "            "
    echo "            "
    echo "            Welcome to Server Installation Script"
    echo "            This Script Will Install Apache SSL LetsEncrypt"
    echo "            and Install Bind DNS and configure Nameservers with provided Domain"
    echo "            NOTE : This Script Working With Centos OS Only"
    echo "            "
    echo "            "
    echo "            Checking OS Comptibility.........."
    sleep 2
	if [[ $EUID -ne 0 ]]; then
		echo "Error:This script must be run as root!" 1>&2
		exit 1
	fi
	echo "            "
	echo "            "
	echo "            Your OS Supported Our Script"
	echo -n "pleas enter ( y ) to Continue or ( n ) leave the installtion : "
	    read choise1
		if [ $choise1 = "y" ]; then
		    echo "Thanks for Your Choise the Script Will be Install Now"
            chmod -R +x includes
		    sh includes/Installation.sh
		else 
		    echo "Thanks for using our scripts goodby"
		    exit
		fi


else

if [ $choise2 = "2" ]; then
    echo "Please Wait ...."
    sleep 2
    sh includes/New_Domain.sh
fi

if [ $choise2 = "3" ]; then
    echo "Please Wait ...."
    sleep 2
    sh includes/Remove_Domain.sh
fi

if [ $choise2 = "4" ]; then
    echo "Please Wait ...."
    sleep 2
    sh includes/New_Alias.sh
fi

if [ $choise2 = "5" ]; then
    echo "Please Wait ...."
    sleep 2
    sh includes/Remove_Alias.sh
fi

fi
